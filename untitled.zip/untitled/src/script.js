function restart() {
  if (confirm("Are you sure you want to reset ALL progress?")) {
    localStorage.clear();
    coins = 0;
    clickPower = 1;
    autoClickers = 0;
    prestigeLevel = 0;
    prestigePoints = 0;
    offlineUpgrades = 0;
    perks = {};
    achievements = new Set();
    save();
    location.reload();
  }
}


